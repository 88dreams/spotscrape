"""
SpotScrape - A tool for scraping music information and creating Spotify playlists
"""

__version__ = "1.0.0"
__author__ = "88dreams" 